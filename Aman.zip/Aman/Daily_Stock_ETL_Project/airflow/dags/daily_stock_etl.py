from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime, timedelta
import requests
import pandas as pd
import boto3
import os
from dotenv import load_dotenv

load_dotenv()

FMP_API_KEY = os.getenv('FMP_API_KEY')
AWS_ACCESS_KEY_ID = os.getenv('AWS_ACCESS_KEY_ID')
AWS_SECRET_ACCESS_KEY = os.getenv('AWS_SECRET_ACCESS_KEY')
AWS_REGION = os.getenv('AWS_REGION')
AWS_BUCKET_NAME = os.getenv('AWS_BUCKET_NAME')
stock_symbol = "AAPL"

default_args = {
    'owner': 'airflow',
    'start_date': datetime(2024, 1, 1),
    'retries': 1,
    'retry_delay': timedelta(minutes=5)
}

dag = DAG(
    'daily_stock_price_etl',
    default_args=default_args,
    schedule_interval='@daily',
    catchup=False,
    description='Daily stock price ETL'
)

def extract_data():
    url = f"https://financialmodelingprep.com/api/v3/historical-price-full/{stock_symbol}?timeseries=200&apikey={FMP_API_KEY}"
    response = requests.get(url)
    data = response.json()
    if 'historical' in data:
        df = pd.DataFrame(data['historical'])
        df.to_csv(f"/tmp/{stock_symbol}_raw.csv", index=False)
    else:
        raise Exception("No data found.")

def transform_data():
    df = pd.read_csv(f"/tmp/{stock_symbol}_raw.csv")
    df['SMA_50'] = df['close'].rolling(50).mean()
    df['SMA_200'] = df['close'].rolling(200).mean()
    df.to_csv(f"/tmp/{stock_symbol}_transformed.csv", index=False)

def upload_to_s3():
    session = boto3.Session(
        aws_access_key_id=AWS_ACCESS_KEY_ID,
        aws_secret_access_key=AWS_SECRET_ACCESS_KEY,
        region_name=AWS_REGION
    )
    s3 = session.resource('s3')
    file_path = f"/tmp/{stock_symbol}_transformed.csv"
    key = f"{stock_symbol}_data/{datetime.now().strftime('%Y-%m-%d')}.csv"
    s3.Bucket(AWS_BUCKET_NAME).upload_file(file_path, key)

t1 = PythonOperator(task_id='extract', python_callable=extract_data, dag=dag)
t2 = PythonOperator(task_id='transform', python_callable=transform_data, dag=dag)
t3 = PythonOperator(task_id='upload', python_callable=upload_to_s3, dag=dag)

t1 >> t2 >> t3